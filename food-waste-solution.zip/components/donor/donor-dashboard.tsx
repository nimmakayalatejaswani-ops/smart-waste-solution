"use client"

import { useState } from "react"
import { useAuth } from "@/context/auth-context"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MOCK_LISTINGS, type FoodListing } from "@/lib/mock-data"
import { DonorListingForm } from "./donor-listing-form"
import { DonorListingCard } from "./donor-listing-card"
import { Plus, Package, Clock, CheckCircle, AlertTriangle } from "lucide-react"

export function DonorDashboard() {
  const { user } = useAuth()
  const [showNewListingForm, setShowNewListingForm] = useState(false)
  const [listings, setListings] = useState<FoodListing[]>(MOCK_LISTINGS.filter((l) => l.donorId === "1"))

  // Stats
  const activeListings = listings.filter((l) => l.status === "available").length
  const claimedListings = listings.filter((l) => l.status === "claimed").length
  const completedListings = listings.filter((l) => l.status === "picked_up").length
  const totalServings = listings.reduce((sum, l) => sum + l.servings, 0)

  const handleNewListing = (
    listing: Omit<
      FoodListing,
      "id" | "donorId" | "donorName" | "donorAddress" | "donorPhone" | "latitude" | "longitude" | "status" | "createdAt"
    >,
  ) => {
    const newListing: FoodListing = {
      ...listing,
      id: Date.now().toString(),
      donorId: user?.id || "1",
      donorName: user?.name || "Unknown Donor",
      donorAddress: user?.address || "Unknown Address",
      donorPhone: user?.phone || "Unknown Phone",
      latitude: user?.latitude || 40.7128,
      longitude: user?.longitude || -74.006,
      status: "available",
      createdAt: new Date(),
    }
    setListings((prev) => [newListing, ...prev])
    setShowNewListingForm(false)
  }

  const handleCancelListing = (id: string) => {
    setListings((prev) => prev.filter((l) => l.id !== id))
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Welcome back, {user?.name}</h1>
          <p className="text-muted-foreground">Manage your food donations and track their impact.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Package className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{activeListings}</p>
                <p className="text-sm text-muted-foreground">Active Listings</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-accent/10 flex items-center justify-center">
                <Clock className="h-6 w-6 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{claimedListings}</p>
                <p className="text-sm text-muted-foreground">Pending Pickup</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-green-100 flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{completedListings}</p>
                <p className="text-sm text-muted-foreground">Completed</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-orange-100 flex items-center justify-center">
                <AlertTriangle className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalServings}</p>
                <p className="text-sm text-muted-foreground">Servings Donated</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* New Listing Button */}
        <div className="mb-6">
          <Button onClick={() => setShowNewListingForm(true)} className="gap-2">
            <Plus className="h-4 w-4" />
            Post New Food Listing
          </Button>
        </div>

        {/* New Listing Form Modal */}
        {showNewListingForm && (
          <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4">
            <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <CardHeader>
                <CardTitle>Post New Food Listing</CardTitle>
                <CardDescription>Fill in the details about the surplus food you want to donate</CardDescription>
              </CardHeader>
              <CardContent>
                <DonorListingForm onSubmit={handleNewListing} onCancel={() => setShowNewListingForm(false)} />
              </CardContent>
            </Card>
          </div>
        )}

        {/* Listings Tabs */}
        <Tabs defaultValue="active" className="space-y-6">
          <TabsList>
            <TabsTrigger value="active">Active ({activeListings})</TabsTrigger>
            <TabsTrigger value="claimed">Claimed ({claimedListings})</TabsTrigger>
            <TabsTrigger value="history">History ({completedListings})</TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="space-y-4">
            {listings.filter((l) => l.status === "available").length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="p-12 text-center">
                  <Package className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="font-semibold mb-2">No active listings</h3>
                  <p className="text-muted-foreground mb-4">Post your surplus food to help those in need</p>
                  <Button onClick={() => setShowNewListingForm(true)} variant="outline">
                    Create Your First Listing
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {listings
                  .filter((l) => l.status === "available")
                  .map((listing) => (
                    <DonorListingCard key={listing.id} listing={listing} onCancel={handleCancelListing} />
                  ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="claimed" className="space-y-4">
            {listings.filter((l) => l.status === "claimed").length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="p-12 text-center">
                  <Clock className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="font-semibold mb-2">No pending pickups</h3>
                  <p className="text-muted-foreground">Claimed listings will appear here</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {listings
                  .filter((l) => l.status === "claimed")
                  .map((listing) => (
                    <DonorListingCard key={listing.id} listing={listing} onCancel={handleCancelListing} showClaimInfo />
                  ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            {listings.filter((l) => l.status === "picked_up").length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="p-12 text-center">
                  <CheckCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="font-semibold mb-2">No completed donations yet</h3>
                  <p className="text-muted-foreground">Your completed donations will appear here</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {listings
                  .filter((l) => l.status === "picked_up")
                  .map((listing) => (
                    <DonorListingCard key={listing.id} listing={listing} showClaimInfo />
                  ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
