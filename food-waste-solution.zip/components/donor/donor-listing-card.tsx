"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { type FoodListing, formatTimeRemaining, getCategoryColor } from "@/lib/mock-data"
import { Clock, Users, X } from "lucide-react"

interface DonorListingCardProps {
  listing: FoodListing
  onCancel?: (id: string) => void
  showClaimInfo?: boolean
}

export function DonorListingCard({ listing, onCancel, showClaimInfo }: DonorListingCardProps) {
  const timeRemaining = formatTimeRemaining(listing.expiresAt)

  return (
    <Card className="overflow-hidden">
      <div className="relative h-40">
        <img
          src={listing.imageUrl || "/placeholder.svg?height=160&width=400&query=food donation"}
          alt={listing.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-3 left-3 flex gap-2">
          <Badge className={getCategoryColor(listing.category)}>{listing.category}</Badge>
          <Badge variant={timeRemaining.urgent ? "destructive" : "secondary"} className="gap-1">
            <Clock className="h-3 w-3" />
            {timeRemaining.text}
          </Badge>
        </div>
      </div>
      <CardContent className="p-4 space-y-4">
        <div>
          <h3 className="font-semibold text-lg mb-1">{listing.title}</h3>
          <p className="text-sm text-muted-foreground line-clamp-2">{listing.description}</p>
        </div>

        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            {listing.servings} servings
          </span>
          <span>{listing.quantity}</span>
        </div>

        {showClaimInfo && listing.claimedByName && (
          <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
            <p className="text-sm font-medium text-primary">Claimed by {listing.claimedByName}</p>
            <p className="text-xs text-muted-foreground mt-1">Awaiting pickup</p>
          </div>
        )}

        <div className="flex items-center gap-2 text-sm">
          <Clock className="h-4 w-4 text-muted-foreground" />
          <span>
            Pickup: {listing.pickupStart.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} -{" "}
            {listing.pickupEnd.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </span>
        </div>

        {onCancel && listing.status === "available" && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => onCancel(listing.id)}
            className="w-full text-destructive hover:text-destructive gap-2"
          >
            <X className="h-4 w-4" />
            Cancel Listing
          </Button>
        )}
      </CardContent>
    </Card>
  )
}
