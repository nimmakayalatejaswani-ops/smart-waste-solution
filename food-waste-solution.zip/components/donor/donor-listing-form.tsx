"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { FoodListing } from "@/lib/mock-data"
import { Loader2 } from "lucide-react"

interface DonorListingFormProps {
  onSubmit: (
    listing: Omit<
      FoodListing,
      "id" | "donorId" | "donorName" | "donorAddress" | "donorPhone" | "latitude" | "longitude" | "status" | "createdAt"
    >,
  ) => void
  onCancel: () => void
}

export function DonorListingForm({ onSubmit, onCancel }: DonorListingFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "cooked" as FoodListing["category"],
    quantity: "",
    servings: "",
    expiryHours: "2",
    pickupStartMinutes: "30",
    pickupEndHours: "3",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const now = new Date()
    const listing = {
      title: formData.title,
      description: formData.description,
      category: formData.category,
      quantity: formData.quantity,
      servings: Number.parseInt(formData.servings),
      expiresAt: new Date(now.getTime() + Number.parseInt(formData.expiryHours) * 60 * 60 * 1000),
      pickupStart: new Date(now.getTime() + Number.parseInt(formData.pickupStartMinutes) * 60 * 1000),
      pickupEnd: new Date(now.getTime() + Number.parseInt(formData.pickupEndHours) * 60 * 60 * 1000),
    }

    onSubmit(listing)
    setIsSubmitting(false)
  }

  const updateField = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="title">Food Title</Label>
        <Input
          id="title"
          placeholder="e.g., Fresh Vegetable Curry & Rice"
          value={formData.title}
          onChange={(e) => updateField("title", e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          placeholder="Describe the food, how it was prepared, and any allergen information..."
          value={formData.description}
          onChange={(e) => updateField("description", e.target.value)}
          rows={3}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="category">Category</Label>
          <Select value={formData.category} onValueChange={(value) => updateField("category", value)}>
            <SelectTrigger id="category">
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="cooked">Cooked Food</SelectItem>
              <SelectItem value="bakery">Bakery Items</SelectItem>
              <SelectItem value="produce">Fresh Produce</SelectItem>
              <SelectItem value="packaged">Packaged Food</SelectItem>
              <SelectItem value="beverages">Beverages</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="quantity">Quantity</Label>
          <Input
            id="quantity"
            placeholder="e.g., 5 large containers"
            value={formData.quantity}
            onChange={(e) => updateField("quantity", e.target.value)}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="servings">Approximate Servings</Label>
          <Input
            id="servings"
            type="number"
            placeholder="25"
            value={formData.servings}
            onChange={(e) => updateField("servings", e.target.value)}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="expiryHours">Expires In (hours)</Label>
          <Select value={formData.expiryHours} onValueChange={(value) => updateField("expiryHours", value)}>
            <SelectTrigger id="expiryHours">
              <SelectValue placeholder="Select time" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">1 hour</SelectItem>
              <SelectItem value="2">2 hours</SelectItem>
              <SelectItem value="4">4 hours</SelectItem>
              <SelectItem value="8">8 hours</SelectItem>
              <SelectItem value="24">24 hours</SelectItem>
              <SelectItem value="48">48 hours</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="pickupStartMinutes">Pickup Available In</Label>
          <Select
            value={formData.pickupStartMinutes}
            onValueChange={(value) => updateField("pickupStartMinutes", value)}
          >
            <SelectTrigger id="pickupStartMinutes">
              <SelectValue placeholder="Select time" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="0">Now</SelectItem>
              <SelectItem value="15">15 minutes</SelectItem>
              <SelectItem value="30">30 minutes</SelectItem>
              <SelectItem value="60">1 hour</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="pickupEndHours">Pickup Window Ends</Label>
          <Select value={formData.pickupEndHours} onValueChange={(value) => updateField("pickupEndHours", value)}>
            <SelectTrigger id="pickupEndHours">
              <SelectValue placeholder="Select time" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">1 hour</SelectItem>
              <SelectItem value="2">2 hours</SelectItem>
              <SelectItem value="3">3 hours</SelectItem>
              <SelectItem value="4">4 hours</SelectItem>
              <SelectItem value="6">6 hours</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1 bg-transparent">
          Cancel
        </Button>
        <Button type="submit" className="flex-1" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Posting...
            </>
          ) : (
            "Post Listing"
          )}
        </Button>
      </div>
    </form>
  )
}
