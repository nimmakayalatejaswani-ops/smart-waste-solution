"use client"

import { useState } from "react"
import { useAuth } from "@/context/auth-context"
import { Header } from "@/components/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { MOCK_LISTINGS, MOCK_NGOS, formatTimeRemaining } from "@/lib/mock-data"
import {
  Package,
  Users,
  Building2,
  TrendingUp,
  CheckCircle,
  XCircle,
  Clock,
  Search,
  MoreHorizontal,
  Shield,
  AlertTriangle,
} from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface Donor {
  id: string
  name: string
  email: string
  phone: string
  address: string
  verified: boolean
  totalDonations: number
  joinedAt: Date
}

const MOCK_DONORS: Donor[] = [
  {
    id: "1",
    name: "Green Valley Restaurant",
    email: "contact@greenvalley.com",
    phone: "+1 555-0123",
    address: "123 Main St, Downtown",
    verified: true,
    totalDonations: 45,
    joinedAt: new Date("2024-01-15"),
  },
  {
    id: "4",
    name: "Sunrise Bakery",
    email: "hello@sunrisebakery.com",
    phone: "+1 555-0789",
    address: "789 Baker St, Uptown",
    verified: true,
    totalDonations: 78,
    joinedAt: new Date("2024-02-01"),
  },
  {
    id: "5",
    name: "City Conference Center",
    email: "events@citycc.com",
    phone: "+1 555-0500",
    address: "500 Convention Blvd",
    verified: true,
    totalDonations: 23,
    joinedAt: new Date("2024-03-10"),
  },
  {
    id: "6",
    name: "Fresh Farms Market",
    email: "info@freshfarms.com",
    phone: "+1 555-0200",
    address: "200 Market Way",
    verified: false,
    totalDonations: 0,
    joinedAt: new Date("2025-01-05"),
  },
]

export function AdminDashboard() {
  const { user } = useAuth()
  const [donors, setDonors] = useState<Donor[]>(MOCK_DONORS)
  const [ngos, setNgos] = useState(MOCK_NGOS)
  const [searchQuery, setSearchQuery] = useState("")

  // Stats
  const totalListings = MOCK_LISTINGS.length
  const activeListings = MOCK_LISTINGS.filter((l) => l.status === "available").length
  const totalDonors = donors.length
  const verifiedDonors = donors.filter((d) => d.verified).length
  const totalNGOs = ngos.length
  const verifiedNGOs = ngos.filter((n) => n.verified).length
  const totalServingsRescued = MOCK_LISTINGS.reduce((sum, l) => sum + l.servings, 0)

  const handleVerifyDonor = (id: string) => {
    setDonors((prev) => prev.map((d) => (d.id === id ? { ...d, verified: true } : d)))
  }

  const handleVerifyNGO = (id: string) => {
    setNgos((prev) => prev.map((n) => (n.id === id ? { ...n, verified: true } : n)))
  }

  const handleSuspendDonor = (id: string) => {
    setDonors((prev) => prev.filter((d) => d.id !== id))
  }

  const handleSuspendNGO = (id: string) => {
    setNgos((prev) => prev.filter((n) => n.id !== id))
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome back, {user?.name}. Manage users and monitor platform activity.
          </p>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Package className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalListings}</p>
                <p className="text-sm text-muted-foreground">Total Listings</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-accent/10 flex items-center justify-center">
                <Building2 className="h-6 w-6 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalDonors}</p>
                <p className="text-sm text-muted-foreground">Donors</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-green-100 flex items-center justify-center">
                <Users className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalNGOs}</p>
                <p className="text-sm text-muted-foreground">NGOs</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-orange-100 flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalServingsRescued}</p>
                <p className="text-sm text-muted-foreground">Servings Rescued</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Pending Verifications Alert */}
        {(donors.some((d) => !d.verified) || ngos.some((n) => !n.verified)) && (
          <Card className="mb-8 border-warning bg-warning/5">
            <CardContent className="p-4 flex items-center gap-4">
              <AlertTriangle className="h-6 w-6 text-warning" />
              <div className="flex-1">
                <p className="font-medium">Pending Verifications</p>
                <p className="text-sm text-muted-foreground">
                  {donors.filter((d) => !d.verified).length} donor(s) and {ngos.filter((n) => !n.verified).length}{" "}
                  NGO(s) awaiting verification
                </p>
              </div>
              <Button variant="outline" size="sm">
                Review Now
              </Button>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="donors">Donors ({totalDonors})</TabsTrigger>
            <TabsTrigger value="ngos">NGOs ({totalNGOs})</TabsTrigger>
            <TabsTrigger value="listings">Listings ({activeListings})</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Latest platform activity</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {MOCK_LISTINGS.slice(0, 5).map((listing) => {
                      const timeRemaining = formatTimeRemaining(listing.expiresAt)
                      return (
                        <div key={listing.id} className="flex items-start gap-3 pb-3 border-b last:border-0">
                          <div
                            className={`h-8 w-8 rounded-full ${listing.status === "claimed" ? "bg-accent/20" : "bg-primary/20"} flex items-center justify-center`}
                          >
                            {listing.status === "claimed" ? (
                              <CheckCircle className="h-4 w-4 text-accent" />
                            ) : (
                              <Package className="h-4 w-4 text-primary" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{listing.title}</p>
                            <p className="text-xs text-muted-foreground">
                              {listing.status === "claimed"
                                ? `Claimed by ${listing.claimedByName}`
                                : `Posted by ${listing.donorName}`}
                            </p>
                          </div>
                          <Badge variant={timeRemaining.urgent ? "destructive" : "secondary"} className="text-xs">
                            {timeRemaining.text}
                          </Badge>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Top Performers */}
              <Card>
                <CardHeader>
                  <CardTitle>Top Performers</CardTitle>
                  <CardDescription>Most active users this month</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground mb-2">Top Donors</p>
                      {donors
                        .filter((d) => d.verified)
                        .sort((a, b) => b.totalDonations - a.totalDonations)
                        .slice(0, 3)
                        .map((donor, index) => (
                          <div key={donor.id} className="flex items-center gap-3 py-2">
                            <span className="text-lg font-bold text-muted-foreground w-6">{index + 1}</span>
                            <div className="flex-1">
                              <p className="font-medium text-sm">{donor.name}</p>
                              <p className="text-xs text-muted-foreground">{donor.totalDonations} donations</p>
                            </div>
                            <Badge variant="outline">{donor.totalDonations * 15} servings</Badge>
                          </div>
                        ))}
                    </div>
                    <div className="pt-4 border-t">
                      <p className="text-sm font-medium text-muted-foreground mb-2">Top NGOs</p>
                      {ngos
                        .sort((a, b) => b.totalPickups - a.totalPickups)
                        .slice(0, 3)
                        .map((ngo, index) => (
                          <div key={ngo.id} className="flex items-center gap-3 py-2">
                            <span className="text-lg font-bold text-muted-foreground w-6">{index + 1}</span>
                            <div className="flex-1">
                              <p className="font-medium text-sm">{ngo.name}</p>
                              <p className="text-xs text-muted-foreground">{ngo.totalPickups} pickups</p>
                            </div>
                            <div className="flex items-center gap-1 text-amber-500">
                              <span className="text-sm font-medium">{ngo.rating}</span>
                              <span className="text-xs">★</span>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Donors Tab */}
          <TabsContent value="donors" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <CardTitle>Manage Donors</CardTitle>
                    <CardDescription>
                      {verifiedDonors} verified, {totalDonors - verifiedDonors} pending
                    </CardDescription>
                  </div>
                  <div className="relative w-full md:w-64">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search donors..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {donors
                    .filter(
                      (d) =>
                        d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        d.email.toLowerCase().includes(searchQuery.toLowerCase()),
                    )
                    .map((donor) => (
                      <div
                        key={donor.id}
                        className="flex items-center gap-4 p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                      >
                        <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                          <Building2 className="h-6 w-6 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-semibold truncate">{donor.name}</p>
                            {donor.verified ? (
                              <Badge variant="outline" className="text-green-600 border-green-200 bg-green-50">
                                <CheckCircle className="h-3 w-3 mr-1" />
                                Verified
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="text-amber-600 border-amber-200 bg-amber-50">
                                <Clock className="h-3 w-3 mr-1" />
                                Pending
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{donor.email}</p>
                          <p className="text-xs text-muted-foreground">
                            {donor.totalDonations} donations • Joined {donor.joinedAt.toLocaleDateString()}
                          </p>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {!donor.verified && (
                              <DropdownMenuItem onClick={() => handleVerifyDonor(donor.id)}>
                                <Shield className="h-4 w-4 mr-2" />
                                Verify Donor
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem
                              onClick={() => handleSuspendDonor(donor.id)}
                              className="text-destructive focus:text-destructive"
                            >
                              <XCircle className="h-4 w-4 mr-2" />
                              Suspend Donor
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* NGOs Tab */}
          <TabsContent value="ngos" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <CardTitle>Manage NGOs</CardTitle>
                    <CardDescription>
                      {verifiedNGOs} verified, {totalNGOs - verifiedNGOs} pending
                    </CardDescription>
                  </div>
                  <div className="relative w-full md:w-64">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search NGOs..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {ngos
                    .filter(
                      (n) =>
                        n.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        n.email.toLowerCase().includes(searchQuery.toLowerCase()),
                    )
                    .map((ngo) => (
                      <div
                        key={ngo.id}
                        className="flex items-center gap-4 p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                      >
                        <div className="h-12 w-12 rounded-full bg-accent/10 flex items-center justify-center">
                          <Users className="h-6 w-6 text-accent" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-semibold truncate">{ngo.name}</p>
                            {ngo.verified ? (
                              <Badge variant="outline" className="text-green-600 border-green-200 bg-green-50">
                                <CheckCircle className="h-3 w-3 mr-1" />
                                Verified
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="text-amber-600 border-amber-200 bg-amber-50">
                                <Clock className="h-3 w-3 mr-1" />
                                Pending
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{ngo.email}</p>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <span>{ngo.totalPickups} pickups</span>
                            <span>•</span>
                            <span>Capacity: {ngo.capacity}</span>
                            <span>•</span>
                            <span className="flex items-center gap-1 text-amber-500">{ngo.rating} ★</span>
                          </div>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {!ngo.verified && (
                              <DropdownMenuItem onClick={() => handleVerifyNGO(ngo.id)}>
                                <Shield className="h-4 w-4 mr-2" />
                                Verify NGO
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem
                              onClick={() => handleSuspendNGO(ngo.id)}
                              className="text-destructive focus:text-destructive"
                            >
                              <XCircle className="h-4 w-4 mr-2" />
                              Suspend NGO
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Listings Tab */}
          <TabsContent value="listings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Active Listings</CardTitle>
                <CardDescription>Monitor and manage food listings</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {MOCK_LISTINGS.filter((l) => l.status === "available" || l.status === "claimed").map((listing) => {
                    const timeRemaining = formatTimeRemaining(listing.expiresAt)
                    return (
                      <div
                        key={listing.id}
                        className="flex items-center gap-4 p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                      >
                        <img
                          src={listing.imageUrl || "/placeholder.svg?height=60&width=60&query=food"}
                          alt={listing.title}
                          className="h-14 w-14 rounded-lg object-cover"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-semibold truncate">{listing.title}</p>
                            <Badge variant={listing.status === "claimed" ? "default" : "secondary"}>
                              {listing.status}
                            </Badge>
                            <Badge variant={timeRemaining.urgent ? "destructive" : "outline"}>
                              {timeRemaining.text}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{listing.donorName}</p>
                          <p className="text-xs text-muted-foreground">
                            {listing.servings} servings • {listing.quantity}
                          </p>
                        </div>
                        {listing.status === "claimed" && (
                          <div className="text-right">
                            <p className="text-sm font-medium text-primary">Claimed</p>
                            <p className="text-xs text-muted-foreground">{listing.claimedByName}</p>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
