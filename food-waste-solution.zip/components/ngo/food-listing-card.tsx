"use client"

import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { type FoodListing, formatTimeRemaining, getCategoryColor } from "@/lib/mock-data"
import { Clock, Users, MapPin, Building2 } from "lucide-react"

interface FoodListingCardProps {
  listing: FoodListing
  distance: number
  onClaim: (id: string) => void
}

export function FoodListingCard({ listing, distance, onClaim }: FoodListingCardProps) {
  const timeRemaining = formatTimeRemaining(listing.expiresAt)

  return (
    <Card className="overflow-hidden flex flex-col">
      <div className="relative h-36">
        <img
          src={listing.imageUrl || "/placeholder.svg?height=144&width=400&query=food donation"}
          alt={listing.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-3 left-3 flex flex-wrap gap-2">
          <Badge className={getCategoryColor(listing.category)}>{listing.category}</Badge>
          <Badge variant={timeRemaining.urgent ? "destructive" : "secondary"} className="gap-1">
            <Clock className="h-3 w-3" />
            {timeRemaining.text}
          </Badge>
        </div>
        {timeRemaining.urgent && (
          <div className="absolute bottom-0 inset-x-0 bg-destructive/90 text-destructive-foreground text-xs text-center py-1 font-medium">
            URGENT - Expiring Soon!
          </div>
        )}
      </div>
      <CardContent className="p-4 flex-1 space-y-3">
        <div>
          <h3 className="font-semibold text-lg leading-tight mb-1">{listing.title}</h3>
          <p className="text-sm text-muted-foreground line-clamp-2">{listing.description}</p>
        </div>

        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Building2 className="h-4 w-4" />
          <span className="truncate">{listing.donorName}</span>
        </div>

        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-muted-foreground">
          <span className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            {listing.servings} servings
          </span>
          <span className="flex items-center gap-1">
            <MapPin className="h-4 w-4" />
            {distance.toFixed(1)} mi
          </span>
        </div>

        <div className="flex items-center gap-2 text-sm">
          <Clock className="h-4 w-4 text-muted-foreground" />
          <span>
            Pickup: {listing.pickupStart.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} -{" "}
            {listing.pickupEnd.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </span>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button onClick={() => onClaim(listing.id)} className="w-full">
          Claim This Food
        </Button>
      </CardFooter>
    </Card>
  )
}
