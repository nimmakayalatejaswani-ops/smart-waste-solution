"use client"

import { useState, useMemo } from "react"
import { useAuth } from "@/context/auth-context"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MOCK_LISTINGS, calculateDistance, type FoodListing } from "@/lib/mock-data"
import { FoodListingCard } from "./food-listing-card"
import { MapView } from "./map-view"
import { Search, Package, Clock, CheckCircle, MapPin, Filter, List, Map } from "lucide-react"

export function NGODashboard() {
  const { user } = useAuth()
  const [listings, setListings] = useState<FoodListing[]>(MOCK_LISTINGS)
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState<string>("all")
  const [sortBy, setSortBy] = useState<string>("expiry")
  const [viewMode, setViewMode] = useState<"list" | "map">("list")

  // NGO's location (from user profile or default)
  const ngoLat = user?.latitude || 40.7589
  const ngoLng = user?.longitude || -73.9851

  // Filter and sort listings
  const filteredListings = useMemo(() => {
    return listings
      .filter((l) => l.status === "available")
      .filter((l) => {
        if (searchQuery) {
          const query = searchQuery.toLowerCase()
          return (
            l.title.toLowerCase().includes(query) ||
            l.description.toLowerCase().includes(query) ||
            l.donorName.toLowerCase().includes(query)
          )
        }
        return true
      })
      .filter((l) => {
        if (categoryFilter !== "all") {
          return l.category === categoryFilter
        }
        return true
      })
      .map((l) => ({
        ...l,
        distance: calculateDistance(ngoLat, ngoLng, l.latitude, l.longitude),
      }))
      .sort((a, b) => {
        switch (sortBy) {
          case "expiry":
            return a.expiresAt.getTime() - b.expiresAt.getTime()
          case "distance":
            return a.distance - b.distance
          case "servings":
            return b.servings - a.servings
          default:
            return 0
        }
      })
  }, [listings, searchQuery, categoryFilter, sortBy, ngoLat, ngoLng])

  // Claimed listings for this NGO
  const claimedListings = listings.filter((l) => l.status === "claimed" && l.claimedBy === user?.id)

  // Stats
  const availableCount = listings.filter((l) => l.status === "available").length
  const claimedCount = claimedListings.length
  const completedCount = 12 // Mock completed count
  const totalServingsReceived = 1540 // Mock total

  const handleClaim = (listingId: string) => {
    setListings((prev) =>
      prev.map((l) =>
        l.id === listingId
          ? {
              ...l,
              status: "claimed" as const,
              claimedBy: user?.id,
              claimedByName: user?.name,
            }
          : l,
      ),
    )
  }

  const handleUnclaim = (listingId: string) => {
    setListings((prev) =>
      prev.map((l) =>
        l.id === listingId
          ? {
              ...l,
              status: "available" as const,
              claimedBy: undefined,
              claimedByName: undefined,
            }
          : l,
      ),
    )
  }

  const handleMarkPickedUp = (listingId: string) => {
    setListings((prev) =>
      prev.map((l) =>
        l.id === listingId
          ? {
              ...l,
              status: "picked_up" as const,
            }
          : l,
      ),
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Welcome, {user?.name}</h1>
          <p className="text-muted-foreground">Find and claim available food donations nearby.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Package className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{availableCount}</p>
                <p className="text-sm text-muted-foreground">Available Now</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-accent/10 flex items-center justify-center">
                <Clock className="h-6 w-6 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{claimedCount}</p>
                <p className="text-sm text-muted-foreground">To Pickup</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-green-100 flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{completedCount}</p>
                <p className="text-sm text-muted-foreground">Completed</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-orange-100 flex items-center justify-center">
                <MapPin className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalServingsReceived}</p>
                <p className="text-sm text-muted-foreground">Servings Received</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="browse" className="space-y-6">
          <TabsList>
            <TabsTrigger value="browse">Browse Food ({filteredListings.length})</TabsTrigger>
            <TabsTrigger value="claimed">My Claims ({claimedCount})</TabsTrigger>
          </TabsList>

          <TabsContent value="browse" className="space-y-6">
            {/* Search and Filters */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search food, donors..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                      <SelectTrigger className="w-[140px]">
                        <Filter className="h-4 w-4 mr-2" />
                        <SelectValue placeholder="Category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        <SelectItem value="cooked">Cooked Food</SelectItem>
                        <SelectItem value="bakery">Bakery</SelectItem>
                        <SelectItem value="produce">Produce</SelectItem>
                        <SelectItem value="packaged">Packaged</SelectItem>
                        <SelectItem value="beverages">Beverages</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={sortBy} onValueChange={setSortBy}>
                      <SelectTrigger className="w-[140px]">
                        <SelectValue placeholder="Sort by" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="expiry">Expiring Soon</SelectItem>
                        <SelectItem value="distance">Nearest</SelectItem>
                        <SelectItem value="servings">Most Servings</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="flex border rounded-md">
                      <Button
                        variant={viewMode === "list" ? "secondary" : "ghost"}
                        size="icon"
                        onClick={() => setViewMode("list")}
                        className="rounded-r-none"
                      >
                        <List className="h-4 w-4" />
                      </Button>
                      <Button
                        variant={viewMode === "map" ? "secondary" : "ghost"}
                        size="icon"
                        onClick={() => setViewMode("map")}
                        className="rounded-l-none"
                      >
                        <Map className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Results */}
            {viewMode === "list" ? (
              filteredListings.length === 0 ? (
                <Card className="border-dashed">
                  <CardContent className="p-12 text-center">
                    <Package className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="font-semibold mb-2">No listings found</h3>
                    <p className="text-muted-foreground">Try adjusting your search or filters</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredListings.map((listing) => (
                    <FoodListingCard
                      key={listing.id}
                      listing={listing}
                      distance={listing.distance}
                      onClaim={handleClaim}
                    />
                  ))}
                </div>
              )
            ) : (
              <Card className="overflow-hidden">
                <MapView
                  listings={filteredListings}
                  ngoLocation={{ lat: ngoLat, lng: ngoLng }}
                  onSelectListing={(id) => {
                    // Could show a popup or highlight
                    console.log("Selected listing:", id)
                  }}
                />
              </Card>
            )}
          </TabsContent>

          <TabsContent value="claimed" className="space-y-6">
            {claimedListings.length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="p-12 text-center">
                  <Clock className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="font-semibold mb-2">No claimed listings</h3>
                  <p className="text-muted-foreground">Browse available food and claim what you need</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {claimedListings.map((listing) => (
                  <Card key={listing.id} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">{listing.title}</CardTitle>
                      <CardDescription>{listing.donorName}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="p-3 rounded-lg bg-accent/10 border border-accent/20">
                        <p className="font-medium text-sm">Pickup Location</p>
                        <p className="text-sm text-muted-foreground">{listing.donorAddress}</p>
                        <p className="text-sm text-muted-foreground mt-1">Phone: {listing.donorPhone}</p>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>
                          Pickup: {listing.pickupStart.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} -{" "}
                          {listing.pickupEnd.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </span>
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={() => handleMarkPickedUp(listing.id)} className="flex-1">
                          Mark as Picked Up
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => handleUnclaim(listing.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          Cancel
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
