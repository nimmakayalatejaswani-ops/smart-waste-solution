"use client"

import type { FoodListing } from "@/lib/mock-data"
import { formatTimeRemaining } from "@/lib/mock-data"

interface MapViewProps {
  listings: (FoodListing & { distance: number })[]
  ngoLocation: { lat: number; lng: number }
  onSelectListing: (id: string) => void
}

export function MapView({ listings, ngoLocation, onSelectListing }: MapViewProps) {
  // This is a simplified map representation
  // In a real app, you'd use Mapbox, Google Maps, or Leaflet

  return (
    <div className="relative h-[500px] bg-muted/50 overflow-hidden">
      {/* Map background */}
      <div className="absolute inset-0">
        <img src="/city-map-street-view.jpg" alt="Map" className="w-full h-full object-cover opacity-30" />
      </div>

      {/* Map grid overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(0,0,0,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(0,0,0,0.05)_1px,transparent_1px)] bg-[size:40px_40px]"></div>

      {/* NGO Location marker */}
      <div
        className="absolute z-20"
        style={{
          left: "50%",
          top: "50%",
          transform: "translate(-50%, -50%)",
        }}
      >
        <div className="relative">
          <div className="h-8 w-8 rounded-full bg-primary border-4 border-primary-foreground shadow-lg flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-xs">YOU</span>
          </div>
          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 rotate-45 bg-primary"></div>
        </div>
      </div>

      {/* Food listing markers */}
      {listings.slice(0, 8).map((listing, index) => {
        // Generate pseudo-random positions around the center
        const angle = (index / 8) * Math.PI * 2
        const radius = 80 + ((listing.distance * 20) % 120)
        const x = 50 + Math.cos(angle) * (radius / 5)
        const y = 50 + Math.sin(angle) * (radius / 5)

        const timeRemaining = formatTimeRemaining(listing.expiresAt)

        return (
          <button
            key={listing.id}
            className="absolute z-10 transform -translate-x-1/2 -translate-y-full cursor-pointer group"
            style={{ left: `${x}%`, top: `${y}%` }}
            onClick={() => onSelectListing(listing.id)}
          >
            <div className="relative">
              <div
                className={`h-10 w-10 rounded-full ${timeRemaining.urgent ? "bg-destructive" : "bg-accent"} border-4 border-card shadow-lg flex items-center justify-center transition-transform group-hover:scale-110`}
              >
                <span className="text-foreground font-bold text-sm">{listing.servings}</span>
              </div>
              <div
                className={`absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 rotate-45 ${timeRemaining.urgent ? "bg-destructive" : "bg-accent"}`}
              ></div>

              {/* Tooltip on hover */}
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-3 rounded-lg bg-card border shadow-xl opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity">
                <p className="font-semibold text-sm truncate">{listing.title}</p>
                <p className="text-xs text-muted-foreground truncate">{listing.donorName}</p>
                <div className="flex items-center gap-2 mt-2 text-xs">
                  <span className={timeRemaining.urgent ? "text-destructive font-medium" : "text-muted-foreground"}>
                    {timeRemaining.text}
                  </span>
                  <span className="text-muted-foreground">•</span>
                  <span className="text-muted-foreground">{listing.distance.toFixed(1)} mi</span>
                </div>
              </div>
            </div>
          </button>
        )
      })}

      {/* Legend */}
      <div className="absolute bottom-4 left-4 p-3 rounded-lg bg-card/95 border shadow-lg">
        <p className="text-xs font-medium mb-2">Map Legend</p>
        <div className="space-y-2 text-xs">
          <div className="flex items-center gap-2">
            <div className="h-4 w-4 rounded-full bg-primary"></div>
            <span>Your Location</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-4 w-4 rounded-full bg-accent"></div>
            <span>Available Food</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-4 w-4 rounded-full bg-destructive"></div>
            <span>Expiring Soon</span>
          </div>
        </div>
      </div>

      {/* Info */}
      <div className="absolute top-4 right-4 p-3 rounded-lg bg-card/95 border shadow-lg text-sm">
        <p className="font-medium">{listings.length} listings nearby</p>
        <p className="text-xs text-muted-foreground">Click markers for details</p>
      </div>
    </div>
  )
}
