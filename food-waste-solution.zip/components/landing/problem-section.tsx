import { AlertTriangle, Users, Clock } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export function ProblemSection() {
  const problems = [
    {
      icon: AlertTriangle,
      title: "Food Goes to Waste",
      description: "Large amounts of freshly cooked food from homes, restaurants, and events go to waste daily.",
      stat: "40%",
      statLabel: "of food wasted",
    },
    {
      icon: Users,
      title: "NGOs Struggle",
      description: "Meanwhile, NGOs struggle to source timely, safe, and sufficient food for those in need.",
      stat: "35M",
      statLabel: "food insecure people",
    },
    {
      icon: Clock,
      title: "No Real-time System",
      description: "There is no efficient real-time system to match surplus food with the right NGO before it expires.",
      stat: "2hrs",
      statLabel: "avg food window",
    },
  ]

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">The Problem We&apos;re Solving</h2>
          <p className="text-lg text-muted-foreground">
            Every day, perfectly good food is thrown away while millions go hungry. The missing piece? A system to
            connect them in time.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {problems.map((problem, index) => (
            <Card key={index} className="relative overflow-hidden border-none shadow-lg">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -translate-y-1/2 translate-x-1/2"></div>
              <CardContent className="p-8">
                <div className="mb-6">
                  <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                    <problem.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{problem.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{problem.description}</p>
                </div>
                <div className="pt-4 border-t">
                  <p className="text-3xl font-bold text-primary">{problem.stat}</p>
                  <p className="text-sm text-muted-foreground">{problem.statLabel}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
