import { Upload, Bell, Truck, Heart } from "lucide-react"

export function HowItWorksSection() {
  const steps = [
    {
      icon: Upload,
      title: "Donor Lists Food",
      description: "Restaurants, events, or homes post surplus food with pickup details and expiry time.",
      color: "bg-primary",
    },
    {
      icon: Bell,
      title: "NGOs Get Alerted",
      description: "Nearby verified NGOs receive instant notifications based on location and capacity.",
      color: "bg-accent",
    },
    {
      icon: Truck,
      title: "Quick Pickup",
      description: "NGO claims the listing and coordinates pickup within the time window.",
      color: "bg-primary",
    },
    {
      icon: Heart,
      title: "Food Reaches People",
      description: "Fresh food reaches those in need before it expires. Everyone wins.",
      color: "bg-accent",
    },
  ]

  return (
    <section id="how-it-works" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">How FoodBridge Works</h2>
          <p className="text-lg text-muted-foreground">
            A simple, efficient process that connects food donors with NGOs in real-time.
          </p>
        </div>

        <div className="relative">
          {/* Connection line */}
          <div className="hidden md:block absolute top-16 left-0 right-0 h-0.5 bg-border"></div>

          <div className="grid md:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative text-center">
                <div className="relative z-10 mx-auto mb-6">
                  <div
                    className={`h-16 w-16 mx-auto rounded-2xl ${step.color} flex items-center justify-center shadow-lg`}
                  >
                    <step.icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <div className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full bg-card border-2 flex items-center justify-center text-sm font-bold">
                    {index + 1}
                  </div>
                </div>
                <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
