import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function CTASection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="relative rounded-3xl bg-primary overflow-hidden">
          <div className="absolute inset-0 bg-[url('/abstract-organic-pattern.png')] opacity-10"></div>
          <div className="relative p-8 md:p-16 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">Ready to Make a Difference?</h2>
            <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto mb-8">
              Whether you have surplus food to share or are an NGO looking to serve more people, join FoodBridge today
              and be part of the solution.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" asChild className="gap-2">
                <Link href="/register">
                  Start Donating
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                asChild
                className="bg-transparent text-primary-foreground border-primary-foreground/30 hover:bg-primary-foreground/10"
              >
                <Link href="/register?role=ngo">Register as NGO</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
