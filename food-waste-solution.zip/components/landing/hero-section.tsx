"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Clock, MapPin, Shield } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-primary/5 via-background to-background">
      <div className="container mx-auto px-4 py-20 md:py-32">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              Live Food Rescue Platform
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-balance">
              Bridge the Gap Between <span className="text-primary">Surplus Food</span> and{" "}
              <span className="text-accent">Those in Need</span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-xl">
              Real-time matching connects restaurants, events, and homes with NGOs before food expires. Reduce waste,
              fight hunger, build community.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" asChild className="gap-2">
                <Link href="/register">
                  Start Donating
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/register?role=ngo">Join as NGO</Link>
              </Button>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="h-4 w-4 text-primary" />
                <span>Real-time matching</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 text-primary" />
                <span>Location-based</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Shield className="h-4 w-4 text-primary" />
                <span>Verified NGOs</span>
              </div>
            </div>
          </div>

          <div className="relative hidden lg:block">
            <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-accent/20 rounded-3xl blur-3xl"></div>
            <div className="relative bg-card rounded-3xl border shadow-2xl overflow-hidden">
              <img src="/food-donation-community-volunteers-helping-kitchen.jpg" alt="Community food donation" className="w-full h-auto" />
              <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-card via-card/80 to-transparent p-6">
                <div className="flex items-center gap-4">
                  <div className="flex -space-x-3">
                    <div className="h-10 w-10 rounded-full bg-primary/20 border-2 border-card flex items-center justify-center text-xs font-bold">
                      R
                    </div>
                    <div className="h-10 w-10 rounded-full bg-accent/20 border-2 border-card flex items-center justify-center text-xs font-bold">
                      H
                    </div>
                    <div className="h-10 w-10 rounded-full bg-primary/20 border-2 border-card flex items-center justify-center text-xs font-bold">
                      C
                    </div>
                  </div>
                  <div>
                    <p className="font-semibold text-sm">2,500+ meals rescued today</p>
                    <p className="text-xs text-muted-foreground">From 180 donors to 45 NGOs</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
