import { Card, CardContent } from "@/components/ui/card"
import { TrendingUp, Users, Leaf, Building2 } from "lucide-react"

export function ImpactSection() {
  const stats = [
    { icon: TrendingUp, value: "50,000+", label: "Meals Rescued", color: "text-primary" },
    { icon: Users, value: "120+", label: "Partner NGOs", color: "text-accent" },
    { icon: Building2, value: "500+", label: "Active Donors", color: "text-primary" },
    { icon: Leaf, value: "25 tons", label: "Food Waste Prevented", color: "text-accent" },
  ]

  return (
    <section id="impact" className="py-20 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Impact</h2>
          <p className="text-lg text-muted-foreground">
            Together, we&apos;re making a difference. Every meal rescued is a step toward a more sustainable future.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <Card key={index} className="text-center border-none shadow-lg">
              <CardContent className="p-8">
                <stat.icon className={`h-8 w-8 mx-auto mb-4 ${stat.color}`} />
                <p className="text-3xl md:text-4xl font-bold mb-1">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 rounded-3xl bg-card border shadow-xl overflow-hidden">
          <div className="grid md:grid-cols-2">
            <div className="p-8 md:p-12 flex flex-col justify-center">
              <blockquote className="text-xl md:text-2xl font-medium leading-relaxed mb-6">
                &quot;FoodBridge has transformed how we source food. We now receive real-time alerts for nearby surplus,
                allowing us to serve 40% more meals without increasing our budget.&quot;
              </blockquote>
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center font-bold">
                  MJ
                </div>
                <div>
                  <p className="font-semibold">Maria Johnson</p>
                  <p className="text-sm text-muted-foreground">Director, Hope Foundation</p>
                </div>
              </div>
            </div>
            <div className="relative min-h-[300px] md:min-h-full">
              <img
                src="/volunteer-food-bank-community-service-smiling.jpg"
                alt="Community food bank volunteers"
                className="absolute inset-0 w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
