"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import { DonorDashboard } from "@/components/donor/donor-dashboard"
import { Loader2 } from "lucide-react"

export default function DonorPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/login")
    } else if (!isLoading && user && user.role !== "donor") {
      // Redirect to appropriate dashboard
      if (user.role === "ngo") router.push("/ngo")
      else if (user.role === "admin") router.push("/admin")
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return <DonorDashboard />
}
