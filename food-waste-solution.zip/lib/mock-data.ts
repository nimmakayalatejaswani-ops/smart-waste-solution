export interface FoodListing {
  id: string
  donorId: string
  donorName: string
  donorAddress: string
  donorPhone: string
  latitude: number
  longitude: number
  title: string
  description: string
  category: "cooked" | "packaged" | "produce" | "bakery" | "beverages"
  quantity: string
  servings: number
  expiresAt: Date
  pickupStart: Date
  pickupEnd: Date
  status: "available" | "claimed" | "picked_up" | "expired"
  claimedBy?: string
  claimedByName?: string
  createdAt: Date
  imageUrl?: string
}

export interface NGO {
  id: string
  name: string
  email: string
  phone: string
  address: string
  latitude: number
  longitude: number
  verified: boolean
  capacity: number
  servicesProvided: string[]
  rating: number
  totalPickups: number
}

// Generate mock food listings
export const MOCK_LISTINGS: FoodListing[] = [
  {
    id: "1",
    donorId: "1",
    donorName: "Green Valley Restaurant",
    donorAddress: "123 Main St, Downtown",
    donorPhone: "+1 555-0123",
    latitude: 40.7128,
    longitude: -74.006,
    title: "Fresh Vegetable Curry & Rice",
    description:
      "Leftover from catering event. Well-packaged vegetarian curry with basmati rice. Serves approximately 25 people.",
    category: "cooked",
    quantity: "5 large containers",
    servings: 25,
    expiresAt: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours
    pickupStart: new Date(Date.now() + 30 * 60 * 1000),
    pickupEnd: new Date(Date.now() + 3 * 60 * 60 * 1000),
    status: "available",
    createdAt: new Date(Date.now() - 30 * 60 * 1000),
    imageUrl: "/vegetable-curry-rice-indian-food.jpg",
  },
  {
    id: "2",
    donorId: "4",
    donorName: "Sunrise Bakery",
    donorAddress: "789 Baker St, Uptown",
    donorPhone: "+1 555-0789",
    latitude: 40.7484,
    longitude: -73.9857,
    title: "Assorted Fresh Bread & Pastries",
    description:
      "End of day fresh baked goods including sourdough loaves, croissants, and muffins. All baked this morning.",
    category: "bakery",
    quantity: "3 trays + 2 baskets",
    servings: 40,
    expiresAt: new Date(Date.now() + 8 * 60 * 60 * 1000), // 8 hours
    pickupStart: new Date(Date.now()),
    pickupEnd: new Date(Date.now() + 2 * 60 * 60 * 1000),
    status: "available",
    createdAt: new Date(Date.now() - 15 * 60 * 1000),
    imageUrl: "/fresh-bakery-bread-pastries-croissants.jpg",
  },
  {
    id: "3",
    donorId: "5",
    donorName: "City Conference Center",
    donorAddress: "500 Convention Blvd",
    donorPhone: "+1 555-0500",
    latitude: 40.7549,
    longitude: -73.984,
    title: "Corporate Lunch Buffet Surplus",
    description:
      "Mixed items from corporate event: sandwiches, salads, grilled chicken, and fruit platters. All professionally catered.",
    category: "cooked",
    quantity: "Multiple platters",
    servings: 60,
    expiresAt: new Date(Date.now() + 1 * 60 * 60 * 1000), // 1 hour - URGENT
    pickupStart: new Date(Date.now()),
    pickupEnd: new Date(Date.now() + 1.5 * 60 * 60 * 1000),
    status: "available",
    createdAt: new Date(Date.now() - 45 * 60 * 1000),
    imageUrl: "/corporate-catering-buffet-sandwiches-salad.jpg",
  },
  {
    id: "4",
    donorId: "6",
    donorName: "Fresh Farms Market",
    donorAddress: "200 Market Way",
    donorPhone: "+1 555-0200",
    latitude: 40.7282,
    longitude: -73.7949,
    title: "Organic Produce Box",
    description:
      "Slightly imperfect but perfectly good organic vegetables: tomatoes, peppers, zucchini, and leafy greens.",
    category: "produce",
    quantity: "4 large boxes",
    servings: 30,
    expiresAt: new Date(Date.now() + 48 * 60 * 60 * 1000), // 2 days
    pickupStart: new Date(Date.now() + 60 * 60 * 1000),
    pickupEnd: new Date(Date.now() + 6 * 60 * 60 * 1000),
    status: "available",
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    imageUrl: "/organic-fresh-vegetables-produce-tomatoes.jpg",
  },
  {
    id: "5",
    donorId: "1",
    donorName: "Green Valley Restaurant",
    donorAddress: "123 Main St, Downtown",
    donorPhone: "+1 555-0123",
    latitude: 40.7128,
    longitude: -74.006,
    title: "Pasta & Garlic Bread",
    description: "Fresh pasta with marinara sauce and garlic bread from dinner service.",
    category: "cooked",
    quantity: "3 containers",
    servings: 15,
    expiresAt: new Date(Date.now() + 4 * 60 * 60 * 1000),
    pickupStart: new Date(Date.now() + 30 * 60 * 1000),
    pickupEnd: new Date(Date.now() + 3 * 60 * 60 * 1000),
    status: "claimed",
    claimedBy: "2",
    claimedByName: "Hope Foundation",
    createdAt: new Date(Date.now() - 60 * 60 * 1000),
    imageUrl: "/pasta-marinara-garlic-bread-italian.jpg",
  },
]

export const MOCK_NGOS: NGO[] = [
  {
    id: "2",
    name: "Hope Foundation",
    email: "contact@hopefoundation.org",
    phone: "+1 555-0456",
    address: "456 Oak Ave, Midtown",
    latitude: 40.7589,
    longitude: -73.9851,
    verified: true,
    capacity: 100,
    servicesProvided: ["Homeless Shelter", "Food Distribution", "Community Kitchen"],
    rating: 4.8,
    totalPickups: 234,
  },
  {
    id: "7",
    name: "Community Food Bank",
    email: "info@communityfoodbank.org",
    phone: "+1 555-0777",
    address: "321 Charity Lane",
    latitude: 40.7359,
    longitude: -73.9911,
    verified: true,
    capacity: 200,
    servicesProvided: ["Food Bank", "Meal Programs", "Senior Services"],
    rating: 4.9,
    totalPickups: 567,
  },
  {
    id: "8",
    name: "Helping Hands Mission",
    email: "hello@helpinghands.org",
    phone: "+1 555-0888",
    address: "159 Service Rd",
    latitude: 40.7421,
    longitude: -73.9874,
    verified: true,
    capacity: 75,
    servicesProvided: ["Homeless Outreach", "Hot Meals", "Emergency Aid"],
    rating: 4.7,
    totalPickups: 189,
  },
]

// Helper function to calculate distance between coordinates
export function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959 // Earth's radius in miles
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLon = ((lon2 - lon1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return R * c
}

// Helper function to format time remaining
export function formatTimeRemaining(expiresAt: Date): { text: string; urgent: boolean } {
  const now = new Date()
  const diff = expiresAt.getTime() - now.getTime()

  if (diff <= 0) {
    return { text: "Expired", urgent: true }
  }

  const hours = Math.floor(diff / (1000 * 60 * 60))
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

  if (hours === 0) {
    return { text: `${minutes}m left`, urgent: true }
  } else if (hours < 2) {
    return { text: `${hours}h ${minutes}m left`, urgent: true }
  } else if (hours < 24) {
    return { text: `${hours}h left`, urgent: false }
  } else {
    const days = Math.floor(hours / 24)
    return { text: `${days}d left`, urgent: false }
  }
}

// Helper to get category color
export function getCategoryColor(category: FoodListing["category"]): string {
  const colors = {
    cooked: "bg-orange-100 text-orange-800",
    packaged: "bg-blue-100 text-blue-800",
    produce: "bg-green-100 text-green-800",
    bakery: "bg-amber-100 text-amber-800",
    beverages: "bg-purple-100 text-purple-800",
  }
  return colors[category]
}
