"use client"

import { createContext, useContext, useState, useCallback, type ReactNode } from "react"

export type UserRole = "donor" | "ngo" | "admin"

export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  organization?: string
  phone?: string
  address?: string
  latitude?: number
  longitude?: number
  verified?: boolean
  createdAt: Date
}

interface AuthContextType {
  user: User | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (data: RegisterData) => Promise<void>
  logout: () => void
}

interface RegisterData {
  name: string
  email: string
  password: string
  role: UserRole
  organization?: string
  phone?: string
  address?: string
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Mock users for demo
const MOCK_USERS: Record<string, User & { password: string }> = {
  "donor@demo.com": {
    id: "1",
    name: "Green Valley Restaurant",
    email: "donor@demo.com",
    password: "demo123",
    role: "donor",
    organization: "Green Valley Restaurant",
    phone: "+1 555-0123",
    address: "123 Main St, Downtown",
    latitude: 40.7128,
    longitude: -74.006,
    verified: true,
    createdAt: new Date("2024-01-15"),
  },
  "ngo@demo.com": {
    id: "2",
    name: "Hope Foundation",
    email: "ngo@demo.com",
    password: "demo123",
    role: "ngo",
    organization: "Hope Foundation",
    phone: "+1 555-0456",
    address: "456 Oak Ave, Midtown",
    latitude: 40.7589,
    longitude: -73.9851,
    verified: true,
    createdAt: new Date("2024-02-20"),
  },
  "admin@demo.com": {
    id: "3",
    name: "Sarah Admin",
    email: "admin@demo.com",
    password: "demo123",
    role: "admin",
    verified: true,
    createdAt: new Date("2024-01-01"),
  },
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const login = useCallback(async (email: string, password: string) => {
    setIsLoading(true)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 800))

    const mockUser = MOCK_USERS[email.toLowerCase()]
    if (mockUser && mockUser.password === password) {
      const { password: _, ...userWithoutPassword } = mockUser
      setUser(userWithoutPassword)
    } else {
      throw new Error("Invalid email or password")
    }

    setIsLoading(false)
  }, [])

  const register = useCallback(async (data: RegisterData) => {
    setIsLoading(true)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const newUser: User = {
      id: Date.now().toString(),
      name: data.name,
      email: data.email,
      role: data.role,
      organization: data.organization,
      phone: data.phone,
      address: data.address,
      verified: false,
      createdAt: new Date(),
    }

    setUser(newUser)
    setIsLoading(false)
  }, [])

  const logout = useCallback(() => {
    setUser(null)
  }, [])

  return <AuthContext.Provider value={{ user, isLoading, login, register, logout }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
